const thiyaSelectorBtn = document.querySelector('#thiya-selector');
const suganeshSelectorBtn = document.querySelector('#suganesh-selector');
const chatHeaders = document.querySelectorAll('.chat-header h2');
const chatContainers = document.querySelectorAll('.chat-window');
const chatMessages = document.querySelectorAll('.chat-messages');
const chatInputForms = document.querySelectorAll('.chat-input-form');
const chatInputs = document.querySelectorAll('.chat-input');
const clearChatBtns = document.querySelectorAll('.clear-chat-button');
const messages = JSON.parse(localStorage.getItem('messages')) || [];
const createChatMessageElement = (message) => `
 <div class="message ${message.sender === 'Thiya' ? 'blue-bg' : 'gray-bg'}">
 <div class="message-sender">${message.sender}</div>
 <div class="message-text">${message.text}</div>
 <div class="message-timestamp">${message.timestamp}</div>
 </div>
`;
window.onload = () => {
 messages.forEach((message) => {
 chatMessages.forEach((chatMessage) => {
 chatMessage.innerHTML += createChatMessageElement(message);
 });
 });
};
let messageSender = 'Thiya';
const updateMessageSender = (name) => {
 messageSender = name;
 chatHeaders.forEach((chatHeader) => {
 chatHeader.innerText = `${messageSender}'s chatting...`;
 });
 chatInputs.forEach((chatInput) => {
 chatInput.placeholder = `Type here, ${messageSender}...`;
 });
 if (name === 'Thiya') {
 thiyaSelectorBtn.classList.add('active-person');
 suganeshSelectorBtn.classList.remove('active-person');
 document.querySelector('.thiya-chat').classList.add('active-chat');
 document.querySelector('.suganesh-chat').classList.remove('active-chat');
 } else {
 suganeshSelectorBtn.classList.add('active-person');
 thiyaSelectorBtn.classList.remove('active-person');
 document.querySelector('.suganesh-chat').classList.add('active-chat');
 document.querySelector('.thiya-chat').classList.remove('active-chat');
 }
 chatInputs[messageSender === 'Thiya' ? 0 : 1].focus();
};
thiyaSelectorBtn.onclick = () => updateMessageSender('Thiya');
suganeshSelectorBtn.onclick = () => updateMessageSender('Suganesh');
const sendMessage = (e) => {
 e.preventDefault();
 const timestamp = new Date().toLocaleString('en-US', { hour: 'numeric', 
minute: 'numeric', hour12: true });
 const message = {
 sender: messageSender,
 text: chatInputs[messageSender === 'Thiya' ? 0 : 1].value,
 timestamp,
 };
 messages.push(message);
 localStorage.setItem('messages', JSON.stringify(messages));
 chatMessages.forEach((chatMessage) => {
 chatMessage.innerHTML += createChatMessageElement(message);
 });
 chatInputForms[messageSender === 'Thiya' ? 0 : 1].reset();
 chatMessages.forEach((chatMessage) => {
 chatMessage.scrollTop = chatMessage.scrollHeight;
 });
};
chatInputForms.forEach((chatInputForm) => {
 chatInputForm.addEventListener('submit', sendMessage);
});
clearChatBtns.forEach((clearChatBtn, index) => {
 clearChatBtn.addEventListener('click', () => {
 localStorage.clear();
 chatMessages.forEach((chatMessage) => {
 chatMessage.innerHTML = '';
 });
 });
});